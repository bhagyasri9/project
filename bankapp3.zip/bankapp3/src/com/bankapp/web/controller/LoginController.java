package com.bankapp.web.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.bankapp.model.entity.Login;

import com.bankapp.model.service.LoginService;

@Controller
public class LoginController {

	private LoginService loginService;

	@Autowired
	public LoginController(LoginService loginService) {
		this.loginService = loginService;
	}

	@GetMapping("/")
	public String home() {
		return "show";
	}

	@GetMapping("login")
	public String loginGet(ModelMap map) {
		map.addAttribute("login", new Login());
		return "login";
	}

	@PostMapping("login")
	public String loginPost(@ModelAttribute("login") Login login, HttpServletRequest req) {

		String username = login.getUserName();
		String password = login.getPassWord();
		boolean isValid = loginService.verifyDetails(username, password);
		if (isValid) {
			Login login1 = loginService.getLogin(username, password);

			HttpSession session = req.getSession();
			session.setAttribute("user", login1);

			return "home";
		} else {
			return "login";
		}
	}
}
