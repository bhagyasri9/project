package com.bankapp.web.controller;


import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.bankapp.model.entity.Customer;
import com.bankapp.model.service.CustomerService;
import com.bankapp.web.formbeans.CustomerBean;


@Controller
public class CustomerController {

	private CustomerService customerService;
	
	@Autowired
	public CustomerController(CustomerService customerService) {
		this.customerService = customerService;
	}

	@GetMapping("success")
	public String success() {

		return "success";
	}
	
	@GetMapping("home")
	public String homePage(ModelMap model) {
		// model.addAttribute("withdrawBean",new TransferBean());
		return "home";
	}
	

	@GetMapping("updatecustomer")
	public String addAccountGet(HttpServletRequest req, ModelMap map) {
		int id = Integer.parseInt(req.getParameter("id"));
		Customer account = customerService.getCustomerById(id);
		map.addAttribute("account", account);
		return "updateaccount";
	}

	@GetMapping("addcustomer")
	public String addAccountGet(ModelMap map) {
		map.addAttribute("customerBean", new CustomerBean());
		return "addcustomer";
	}

	@PostMapping("addcustomer")
	public String addAccountPost(@Valid @ModelAttribute("customerBean") Customer customerBean, BindingResult result) {
		if (result.hasErrors()) {
			return "addcustomer";
		} else {
			if (customerBean.getCustId() == 0) {
				customerService.addCustomer(customerBean);
			} else {
				customerService.updateCustomer(customerBean.getCustId(), customerBean);
			}
			return "success";
		}
	}

	
}

