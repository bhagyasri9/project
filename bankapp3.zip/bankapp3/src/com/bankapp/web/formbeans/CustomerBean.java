package com.bankapp.web.formbeans;

import javax.persistence.Column;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.validator.constraints.NotEmpty;

import com.bankapp.model.entity.GenderType;

public class CustomerBean {

	@NotEmpty(message = "Username can not be left blank")
	private Integer CustId;
	
	@NotEmpty(message = "Username can not be left blank")
	private String firstName;
	
	@NotEmpty(message = "Username can not be left blank")
	private String lastName;
	
	@NotEmpty(message = "Username can not be left blank")
	private Integer age;
	
	@NotEmpty(message = "Username can not be left blank")
	private GenderType genderType;
	
	@NotEmpty(message = "Username can not be left blank")
	private String city;
	
	@NotEmpty(message = "Username can not be left blank")
	private String Occupation;
	
	@NotEmpty(message = "Username can not be left blank")
	private String contactNo;

	public Integer getCustId() {
		return CustId;
	}

	public void setCustId(Integer custId) {
		CustId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public GenderType getGenderType() {
		return genderType;
	}

	public void setGenderType(GenderType genderType) {
		this.genderType = genderType;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getOccupation() {
		return Occupation;
	}

	public void setOccupation(String occupation) {
		Occupation = occupation;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public CustomerBean() {
		super();
	}
	
	
	
}
