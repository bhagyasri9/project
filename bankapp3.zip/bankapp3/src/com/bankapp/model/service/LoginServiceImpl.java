package com.bankapp.model.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.bankapp.model.dao.LoginDao;

import com.bankapp.model.entity.Login;

@Service("accountService")
@Transactional
public class LoginServiceImpl implements LoginService {

	private LoginDao loginDao;

	@Autowired
	public LoginServiceImpl(LoginDao loginDao) {
		this.loginDao = loginDao;
	}

	@Override
	public Login getLogin(String userName, String passWord) {
		return loginDao.getLogin(userName, passWord);
	}

	public boolean verifyDetails(String userName, String passWord) {
		Login login = loginDao.getLogin(userName, passWord);
		if (login.getUserName().equals(userName) && login.getPassWord().equals(passWord)) {
			return true;
		} else {
			return false;
		}
	}

}
