package com.bankapp.model.service;

import java.util.List;

import com.bankapp.model.entity.Login;

public interface LoginService {

	public Login getLogin(String userName, String passWord);

	public boolean verifyDetails(String username, String password);


}
