package com.bankapp.model.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bankapp.model.dao.CustomerDao;

import com.bankapp.model.entity.Customer;

@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	private CustomerDao customerDao;

	@Autowired
	public CustomerServiceImpl(CustomerDao customerDao) {
		this.customerDao = customerDao;
	}

	@Override
	public Customer addCustomer(Customer customer) {

		return customerDao.addCustomer(customer);
	}

	@Override
	public Customer updateCustomer(int id, Customer customer) {

		return customerDao.updateCustomer(id, customer);

	}

	@Override
	public Customer getCustomerById(int id) {
		return customerDao.getCustomerById(id);
	}

}
