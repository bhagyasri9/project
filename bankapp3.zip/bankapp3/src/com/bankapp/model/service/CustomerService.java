package com.bankapp.model.service;

import java.util.List;

import com.bankapp.model.entity.Customer;

public interface CustomerService {
	
	public Customer getCustomerById(int id);
	
	public Customer updateCustomer(int id,Customer account);

	public Customer addCustomer(Customer account);
}
