package com.bankapp.model.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="customer_table")
public class Customer {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer CustId;
	
	@Column(nullable=false)
	private String firstName;
	
	@Column(nullable=false)
	private String lastName;
	
	@Column(nullable=false)
	private Integer age;
	
	@Column(nullable=false)
	private String genderType;
	
	@Column(nullable=false)
	private String city;
	
	@Column(nullable=false)
	private String Occupation;
	
	@Column(nullable=false)
	private String contactNo;

	public Integer getCustId() {
		return CustId;
	}

	public void setCustId(Integer custId) {
		CustId = custId;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	

	public String getGenderType() {
		return genderType;
	}

	public void setGenderType(String genderType) {
		this.genderType = genderType;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}
	
	public String getOccupation() {
		return Occupation;
	}

	public void setOccupation(String occupation) {
		Occupation = occupation;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}


	public Customer(String firstName, String lastName, Integer age, String genderType, String city,
			String occupation, String contactNo) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.genderType = genderType;
		this.city = city;
		Occupation = occupation;
		this.contactNo = contactNo;
	}

	public Customer() {
		
	}

	@Override
	public String toString() {
		return "Customer [CustId=" + CustId + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", genderType=" + genderType + ", city=" + city + ", Occupation=" + Occupation + ", contactNo="
				+ contactNo + "]";
	}

	
	
	
	
}
