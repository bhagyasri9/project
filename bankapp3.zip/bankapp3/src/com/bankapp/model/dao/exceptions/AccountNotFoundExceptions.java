package com.bankapp.model.dao.exceptions;

public class AccountNotFoundExceptions extends RuntimeException{

	public AccountNotFoundExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

}
