package com.bankapp.model.dao;
import java.util.*;
import com.bankapp.model.entity.Customer;
public interface CustomerDao {	
	public Customer getCustomerById(int id);
	public Customer updateCustomer(int id,Customer customer);
	public Customer addCustomer(Customer customer);
}
