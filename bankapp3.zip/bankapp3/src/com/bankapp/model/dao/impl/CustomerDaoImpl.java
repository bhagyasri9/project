package com.bankapp.model.dao.impl;

import java.util.List;
import com.bankapp.model.dao.exceptions.*;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.bankapp.model.dao.CustomerDao;

import com.bankapp.model.entity.Customer;



@Repository
public class CustomerDaoImpl implements CustomerDao {
		
	private SessionFactory factory;
	@Autowired
	public CustomerDaoImpl(SessionFactory factory) {
		this.factory = factory;
	}
	
	private Session getSession() {
		return factory.getCurrentSession();
	}


	
	public Customer updateCustomer(int id, Customer customer) {	 	
		Customer customerToUpdate = getCustomerById(id);
		customerToUpdate.setAge(customer.getAge());
		customerToUpdate.setCity(customer.getCity());
		customerToUpdate.setOccupation(customer.getOccupation());
		customerToUpdate.setContactNo(customer.getContactNo());
		getSession().update(customerToUpdate);
		return customerToUpdate;
	}

	
	
	
	@Override
	public Customer getCustomerById(int id) {
		Customer account = getSession().find(Customer.class, id);
		if(account==null) {
			throw new AccountNotFoundExceptions("account with id :"+id+" is not found");
		}
		return account;
	}

	@Override
	public Customer addCustomer(Customer customer) {
		// TODO Auto-generated method stub
		getSession().persist(customer);
		return customer;
	}

}
