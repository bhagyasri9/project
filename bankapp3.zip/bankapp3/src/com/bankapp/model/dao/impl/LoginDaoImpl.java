package com.bankapp.model.dao.impl;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bankapp.model.dao.LoginDao;

import com.bankapp.model.entity.Login;

@Repository
public class LoginDaoImpl implements LoginDao {

	private SessionFactory factory;

	@Autowired
	public LoginDaoImpl(SessionFactory factory) {
		this.factory = factory;
	}

	// this method is used inside my dao layer....session is open by spring and im
	// just asking for it.
	private Session getSession() {
		return factory.getCurrentSession();
	}

	@Override
	public Login getLogin(String userName, String passWord) {
		Query query = getSession().createQuery("from Login where userName=:username1 and passWord=:password1");
		query.setParameter("username1", userName);
		query.setParameter("password1", passWord);
		Login login = (Login) query.getSingleResult();
		return login;
	}

	/*@Override
	public Login getLoginById(int id) {

		Login login = getSession().get(Login.class, id);

		if (user != null)
			return user;
		else
			throw new UserNotFoundException("user with id:" + id + " is not found");
	}*/

}
