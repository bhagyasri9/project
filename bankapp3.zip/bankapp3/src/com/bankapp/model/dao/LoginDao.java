package com.bankapp.model.dao;

import java.util.*;

import com.bankapp.model.entity.Login;

public interface LoginDao {
	
	//public Login getLoginById(int id);	

	public Login getLogin(String userName, String passWord);
}
